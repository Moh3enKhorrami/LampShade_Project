namespace CommentManagement.Infrastructure.EFCore;

public static class CommentTypes
{
    public const int Product = 1;
}