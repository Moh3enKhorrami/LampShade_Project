namespace ShopManagement.Application.Contracts.ProductPicture;

public class ProductPictureSearchModel
{
    public long ProductId { get; set; }
}