namespace ShopManagement.Application.Contracts.Slide;

public class EditSlide : CreateSlide
{
    public long Id { get; set; }
}