using _0_Framework.Application;

namespace ShopManagement.Application.Contracts.Slide;

public interface ISlideApplication
{
    OperationResult Create(CreateSlide comman);
    OperationResult Edit(EditSlide command);
    EditSlide GetDetails(long id);
    OperationResult Remove(long id);
    OperationResult Restore(long id);
    List<SlideViewModel> GetList();

}