using _0_Framework.Domain;
using AccountManagement.Domain.AccountAgg;

namespace AccountManagement.Domain.RoleAgg;

public class Role : EntityBase
{
    public Role(string name)
    {
        Name = name;
        Accounts = new List<Account>();
    }

    public string Name { get; private set; }
    public List<Account> Accounts { get; private set; }

    public void Edit(string name)
    {
        Name = name;
    }
}