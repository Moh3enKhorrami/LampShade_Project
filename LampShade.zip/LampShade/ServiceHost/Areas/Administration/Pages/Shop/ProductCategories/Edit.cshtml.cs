using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ShopManagement.Application.Contracts.ProductCategory;

namespace ServiceHost.Areas.Administration.Pages.Shop.ProductCategories
{
    public class EditModel : PageModel
    {
        public EditProductCategory _editProductCategory;
        private readonly IProductCategoryApplication _productCategoryApplication;

        public EditModel(IProductCategoryApplication productCategoryApplication)
        {
            _productCategoryApplication = productCategoryApplication;
        }
        public void OnGetEdit(long id)
        {
            
            var productCategory = _productCategoryApplication.GetDetails(id);
            
        }

        //public IActionResult OnPostShow(EditProductCategory command)
        //{
           // var result = _productCategoryApplication.Edit(command);
         //   return RedirectToPage(result);
        //}
       
       
    }
}