using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ServiceHost.Pages;

public class AccountModel : PageModel
{
    public void OnGet()
    {
        
    }
}