using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ServiceHost.Pages;

public class AccessDenied : PageModel
{
    public void OnGet()
    {
        
    }
}