namespace _0_Framework.Application;

public class ValidationMessages
{
    public const string IsRequired = "This field must be filled.";
}