namespace _0_Framework.Application;

public class ApplicationMessages
{
    public const string DuplicatedRecord = "The record with the requested information was is Duplicated. Please try again";
    public const string RecordNotFound = "The record with the requested information was not found. Please try again";
    public const string Dulpicated = "It is not possible to register a duplicate record. Try again";
    public const string PasswordsNotMatch = "Passwords do not match. Try again";
}