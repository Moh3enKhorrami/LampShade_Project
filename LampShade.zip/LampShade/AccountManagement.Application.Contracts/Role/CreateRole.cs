namespace AccountManagement.Application.Contracts.Role;

public class CreateRole
{
    public string Name { get; set; }
    
}