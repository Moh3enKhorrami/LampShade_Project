namespace AccountManagement.Application.Contracts.Role;

public class EditRole : CreateRole
{
    public long Id { get; set; }   
}