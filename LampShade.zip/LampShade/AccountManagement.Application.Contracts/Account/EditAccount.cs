namespace AccountManagement.Application.Contracts.Account;

public class EditAccount : CreateAccount
{
    public long Id { get; set; }
}