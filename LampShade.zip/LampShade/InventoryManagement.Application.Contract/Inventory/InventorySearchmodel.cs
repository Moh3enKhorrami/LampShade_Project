namespace InventoryManagement.Application.Contract.Inventory;

public class InventorySearchmodel
{
    public long ProductId { get; set; }
    public bool InStock { get; set; }
    
    
}