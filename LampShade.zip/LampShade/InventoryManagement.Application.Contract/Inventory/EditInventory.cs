namespace InventoryManagement.Application.Contract.Inventory;

public class EditInventory : CreateInventory
{
    public long Id { get; set; }
}