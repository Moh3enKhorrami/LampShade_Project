namespace DiscountManagement.Application.Contracts.CustomerDiscount;

public class EditCustomerDiscount : DefineCustomerDiscount
{
    public long Id { get; set; }
    
}