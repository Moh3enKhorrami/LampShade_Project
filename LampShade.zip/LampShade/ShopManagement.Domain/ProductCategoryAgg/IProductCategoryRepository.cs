﻿using System;
using System.Linq.Expressions;
using ShopManagement.Application.Contracts.ProductCategory;

namespace ShopManagement.Domain.ProductCategoryAgg
{
	public interface IProductCategoryRepository
	{
		void Create(ProductCategory entity);
		ProductCategory Get(long id); //? 
		List<ProductCategory> GetAll(); //?chera parantez khali
		bool Exists(Expression<Func<ProductCategory, bool>> expression);   //Soal daram Nafahmidamesh
		void SaveChanges();
		EditProductCategory GetDetails(long id);
		List<ProductCategoryViewModel> Search(ProductCategorySearchModel searchModel);
    }
}

